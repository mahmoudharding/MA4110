test = {   'name': 'q5_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(smallest_change_course, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> smallest_change_course == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
