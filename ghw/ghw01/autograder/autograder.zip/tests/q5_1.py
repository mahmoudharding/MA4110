test = {   'name': 'q5_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(biggest_change, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> biggest_change == max( abs(162 - 63), abs(72 - 175), abs(18 - 53) )\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
