test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(new_year, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> # It looks like you didn't replace the ... with a value or expression;\n>>> new_year != ...\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> new_year == 2020\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
