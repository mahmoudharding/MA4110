test = {   'name': 'q2_1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> # It looks like you didn't replace ... with an answer choice;\n>>> characters_q1 != ...\nTrue", 'hidden': False, 'locked': False},
                                   {   'code': ">>> # It looks like you didn't select 1, 2, 3, 4, or 5;\n>>> # Maybe you typed in the number of periods?;\n>>> characters_q1 in [1,2,3,4,5]\nTrue",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> # We're looking for the number of periods from;\n"
                                               '>>> # the chapter with the most number of characters;\n'
                                               '>>> # This answer indicates the number of periods;\n'
                                               '>>> # in the chapter with the larget number of periods.;\n'
                                               '>>> characters_q1 != 3\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> characters_q1 == 2\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
