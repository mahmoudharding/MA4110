test = {   'name': 'q4_3',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(proportion_in_20th_century, (int, float))\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> proportion_in_20th_century == imdb.where('Year', are.between(1900,1999)).num_rows/imdb.num_rows\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
