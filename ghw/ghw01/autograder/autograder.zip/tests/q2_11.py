test = {   'name': 'q2_11',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(sine_of_pi_over_four, (int, float))\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> sine_of_pi_over_four == math.sin(math.pi/4)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
