test = {   'name': 'q5_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> biggest_rel_change_course in [1,2,3]\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> biggest_rel_change_course == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
